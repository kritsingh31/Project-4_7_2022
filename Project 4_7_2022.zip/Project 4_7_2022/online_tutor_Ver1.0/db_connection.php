<?php
$servername ="localhost";
$username ="root";
$password ="";
$database="online_tutor";
//Create connections
$con = new MySQLi($servername, $username, $password, $database);
?>