Name: Kritika Singh 
Student ID: P22225422

In order to run the website, please double click on index.html page to open in Google Chrome Broswer. 
You will then be able to navigate between pages using navigation bar. 